How to run the Vehicle Parking Management System Project using PHP and MySQL

1. Download the project zip file

2. Extract the file and copy vpms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/Html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name  vpmsdb

6. Import vpmsdb.sql file(given inside the zip package in SQL file folder)

7. Run the script http://localhost/vpms

*****************Admin Credential*****************
Username: admin
Password: 12345

*****************User Credential*****************
Username: 1234567890
Password: Test@123

or Register a new user.