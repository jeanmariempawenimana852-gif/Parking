-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 19 août 2025 à 11:02
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `parking`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `ID` int(10) NOT NULL,
  `Categorie_vehicule` varchar(120) DEFAULT NULL,
  `datecreation` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`ID`, `Categorie_vehicule`, `datecreation`) VALUES
(7, 'Véhicules à 4 roues', '2025-06-28 13:29:16'),
(8, 'Véhicule électrique', '2025-06-28 13:31:40'),
(9, 'Véhicule à deux roues', '2025-06-28 13:32:38'),
(10, 'Vélos', '2025-06-28 13:32:56'),
(11, '12 Roues', '2025-08-19 08:32:11');

-- --------------------------------------------------------

--
-- Structure de la table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `Nom_admin` varchar(120) DEFAULT NULL,
  `nom_utilisateur` varchar(120) DEFAULT NULL,
  `telephone` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `motdepasse` varchar(120) DEFAULT NULL,
  `date_enregistrement` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `Nom_admin`, `nom_utilisateur`, `telephone`, `Email`, `motdepasse`, `date_enregistrement`) VALUES
(1, 'Admin', 'admin', 7898799798, 'tester1@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '2024-05-01 05:38:23');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `ID` int(5) NOT NULL,
  `Prenom` varchar(250) DEFAULT NULL,
  `Nom` varchar(250) DEFAULT NULL,
  `telephone` bigint(10) DEFAULT NULL,
  `Email` varchar(250) DEFAULT NULL,
  `motdepasse` varchar(250) DEFAULT NULL,
  `date_enregistrement` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`ID`, `Prenom`, `Nom`, `telephone`, `Email`, `motdepasse`, `date_enregistrement`) VALUES
(3, 'Evelyne anitha', 'KWIZERA', 62497590, 'evelyneanithakwizera2002@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2025-06-28 13:50:31'),
(4, 'MPAWENIMANA', 'Jean Marie', 65815302, 'jeanmarie@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2025-08-19 08:58:47');

-- --------------------------------------------------------

--
-- Structure de la table `vehicule`
--

CREATE TABLE `vehicule` (
  `ID` int(10) NOT NULL,
  `Numero_parking` varchar(120) DEFAULT NULL,
  `Categorie_vehicule` varchar(120) NOT NULL,
  `compagnie_vehicule` varchar(120) DEFAULT NULL,
  `plaque` varchar(120) DEFAULT NULL,
  `Nom_proprietaire` varchar(120) DEFAULT NULL,
  `Telephone_proprietaire` bigint(10) DEFAULT NULL,
  `temps_entree` timestamp NULL DEFAULT current_timestamp(),
  `temps_sortie` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `frais` varchar(120) NOT NULL,
  `Remark` mediumtext NOT NULL,
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `vehicule`
--

INSERT INTO `vehicule` (`ID`, `Numero_parking`, `Categorie_vehicule`, `compagnie_vehicule`, `plaque`, `Nom_proprietaire`, `Telephone_proprietaire`, `temps_entree`, `temps_sortie`, `frais`, `Remark`, `Status`) VALUES
(4, '146033725', 'Véhicule électrique', 'ANGUARD', 'AB12380E', 'KWIZERA  Evelyne anitha', 62497590, '2025-06-28 13:35:52', NULL, '5000', '', ''),
(5, '121283987', 'Véhicule électrique', 'V8', 'A1234', 'Gakiza jean', 62508397, '2025-06-28 14:11:28', NULL, '5000', '', ''),
(6, '101179689', 'Véhicules à 4 roues', 'VANGUARD', 'BE125', 'Irakoze grace', 68505909, '2025-06-28 14:15:39', '2025-06-28 14:16:34', '5000', 'bien', 'Out'),
(7, '187050341', 'Véhicules à 4 roues', 'VANGUARD', 'B1254A', 'MPAWENIMANA Jean marie', 65815302, '2025-08-19 08:43:30', NULL, '5000', '', '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `VehicleCat` (`Categorie_vehicule`);

--
-- Index pour la table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `MobileNumber` (`telephone`);

--
-- Index pour la table `vehicule`
--
ALTER TABLE `vehicule`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `vehicule`
--
ALTER TABLE `vehicule`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
