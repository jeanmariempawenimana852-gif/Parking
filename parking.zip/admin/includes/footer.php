  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    
                    <div class="col-sm-6 text-center">
                        Système de gestion Green parking
                    </div>
                </div>
            </div>
        </footer>