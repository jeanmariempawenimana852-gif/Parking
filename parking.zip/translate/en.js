const translationsFr = {
    home: "Acceuil",
    entries: "Todays Vehicle Entries",
    
};