const translationsFr = {
    home: "Acceuil",
    entries: "Entrées de véhicules d'aujourd'hui",
};